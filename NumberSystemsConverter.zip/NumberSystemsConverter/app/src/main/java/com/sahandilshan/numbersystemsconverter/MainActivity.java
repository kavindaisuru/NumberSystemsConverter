package com.sahandilshan.numbersystemsconverter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextDecimal;
    private EditText editTextBinary;
    private EditText editTextOctal;
    private EditText editTextHexa;
    private Button buttonClear;
    private String value;

    private View.OnFocusChangeListener onFocusChangeListener;
    private TextWatcher textWatcher;
    private int focusedViewId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextDecimal = findViewById(R.id.etvDecimal);
        editTextBinary = findViewById(R.id.etvBinary);
        editTextOctal = findViewById(R.id.etvOctal);
        editTextHexa = findViewById(R.id.etvHexa);

        buttonClear = findViewById(R.id.btnClear);


        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearFields();
            }
        });

        textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                value = ((EditText) findViewById(focusedViewId)).getText().toString().trim();

                if (value.length() > 0) {
                    convertNumber();
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };



        onFocusChangeListener = new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (hasFocus) {
                    //Toast.makeText(getApplicationContext(), "Focus in", Toast.LENGTH_SHORT).show();

                    focusedViewId= v.getId();
                    ((EditText) findViewById(focusedViewId)).addTextChangedListener(textWatcher);

                    GradientDrawable gradientDrawable = new GradientDrawable(
                            GradientDrawable.Orientation.TR_BL,
                            new int[] {Color.parseColor("#cccc30"),Color.parseColor("#EC8282")}
                    );
                    gradientDrawable.setShape(GradientDrawable.RECTANGLE);

                    gradientDrawable.setCornerRadius(10);

                    if(focusedViewId == R.id.etvDecimal){
                        gradientDrawable.setStroke(8,ContextCompat.getColor(getApplicationContext(), android.R.color.holo_green_light));
                    }else{
                        gradientDrawable.setStroke(8,ContextCompat.getColor(getApplicationContext(), android.R.color.holo_blue_light));
                    }


                    v.setBackground(gradientDrawable);

                }else{

                    ((EditText) findViewById(focusedViewId)).removeTextChangedListener(textWatcher);

                     if(focusedViewId == R.id.etvDecimal){
                         v.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.focusview_design));
                     }else{
                         v.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.view_design));
                     }
                }


            }
        };

        editTextDecimal.setOnFocusChangeListener(onFocusChangeListener);
        editTextBinary.setOnFocusChangeListener(onFocusChangeListener);
        editTextOctal.setOnFocusChangeListener(onFocusChangeListener);
        editTextHexa.setOnFocusChangeListener(onFocusChangeListener);


    }

    private void clearFields() {
        editTextDecimal.setText("");
        editTextBinary.setText("");
        editTextOctal.setText("");
        editTextHexa.setText("");
    }

    private void convertNumber() {
        try {
            long num = 0;

            switch (focusedViewId){

                case R.id.etvDecimal:
                    num = Long.parseLong(value);

                    editTextBinary.setText(String.valueOf(Long.toBinaryString(num)));
                    editTextOctal.setText(String.valueOf(Long.toOctalString(num)));
                    editTextHexa.setText(String.valueOf(Long.toHexString(num)));
                    break;

                case R.id.etvBinary:
                    num = Long.parseLong(value,2);

                    editTextDecimal.setText(String.valueOf(num));
                    editTextOctal.setText(String.valueOf(Long.toOctalString(num)));
                    editTextHexa.setText(String.valueOf(Long.toHexString(num)));
                    break;

                case R.id.etvOctal:
                    num = Long.parseLong(value,8);

                    editTextDecimal.setText(String.valueOf(num));
                    editTextBinary.setText(String.valueOf(Long.toBinaryString(num)));
                    editTextHexa.setText(String.valueOf(Long.toHexString(num)));
                    break;

                case R.id.etvHexa:

                    num = Long.parseLong(value,16);

                    editTextDecimal.setText(String.valueOf(num));
                    editTextBinary.setText(String.valueOf(Long.toBinaryString(num)));
                    editTextOctal.setText(String.valueOf(Long.toOctalString(num)));
                    break;
            }


        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}